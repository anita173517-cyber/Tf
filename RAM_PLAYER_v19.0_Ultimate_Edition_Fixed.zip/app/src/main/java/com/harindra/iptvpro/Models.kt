package com.harindra.iptvpro

import java.util.Locale

/**
 * StreamX Media3 Pro v18.1 — Next-Generation Ultra Extreme Correct VOD Edition (Ultra Upgrade).
 *
 * Source-Aware Content Architecture:
 * - Every catalog item carries an explicit, immutable [ContentSourceType]:
 *   - [ContentSourceType.M3U_LIVE] — Imported from M3U/M3U8 playlist (ALWAYS Live TV, NEVER VOD Movie or Series).
 *   - [ContentSourceType.XTREAM_LIVE] — Loaded from Xtream `get_live_streams` (ALWAYS Live TV).
 *   - [ContentSourceType.XTREAM_VOD_MOVIE] — Loaded from Xtream `get_vod_streams` (ONLY Movies section).
 *   - [ContentSourceType.XTREAM_SERIES] — Loaded from Xtream `get_series` (ONLY Series section).
 *   - [ContentSourceType.XTREAM_SERIES_EPISODE] — Loaded from Xtream `get_series_info` (ONLY parent Series episodes).
 * - Eliminates all title/category/extension guesswork so Live TV movie channels ("Bollywood Movies 24x7",
 *   "Hollywood Cinema HD", "Web Series 24x7", etc.) and M3U entries NEVER leak into Movies or Series.
 */
enum class EntertainmentSection(val id: String, val displayTitle: String) {
    LIVE_TV("LIVE_TV", "LIVE TV"),
    MOVIES("MOVIES", "MOVIES"),
    SERIES("SERIES", "SERIES")
}

enum class ContentSourceType(val code: String) {
    M3U_LIVE("M3U_LIVE"),
    XTREAM_LIVE("XTREAM_LIVE"),
    XTREAM_VOD_MOVIE("XTREAM_VOD_MOVIE"),
    XTREAM_SERIES("XTREAM_SERIES"),
    XTREAM_SERIES_EPISODE("XTREAM_SERIES_EPISODE");

    fun isLiveTv(): Boolean = this == M3U_LIVE || this == XTREAM_LIVE
    fun isVodMovie(): Boolean = this == XTREAM_VOD_MOVIE
    fun isSeriesCatalogEntry(): Boolean = this == XTREAM_SERIES
    fun isSeriesEpisodeEntry(): Boolean = this == XTREAM_SERIES_EPISODE

    companion object {
        fun fromCode(raw: String?): ContentSourceType {
            if (raw.isNullOrBlank()) return M3U_LIVE
            return values().firstOrNull { it.code.equals(raw.trim(), ignoreCase = true) } ?: M3U_LIVE
        }
    }
}

enum class VodSortOrder(val id: String, val badgeLabel: String, val fullTitle: String) {
    RECENTLY_ADDED("RECENT", "RECENTLY ADDED", "Recently Added (Provider Order)"),
    NEW_TO_OLD("NEW_OLD", "NEW ↓ OLD", "Release / Added: Newest First"),
    OLD_TO_NEW("OLD_NEW", "OLD ↓ NEW", "Release / Added: Oldest First"),
    A_TO_Z("A_Z", "A ↓ Z", "Alphabetical: A to Z"),
    Z_TO_A("Z_A", "Z ↓ A", "Alphabetical: Z to A");

    fun nextOrder(): VodSortOrder {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }
}

enum class LiveChannelSortOrder(val id: String, val badgeLabel: String, val fullTitle: String) {
    CHANNEL_NUMBER("NUMBER", "CH #", "Channel Number (Default)"),
    A_TO_Z("A_Z", "A ↓ Z", "Alphabetical: A to Z"),
    Z_TO_A("Z_A", "Z ↓ A", "Alphabetical: Z to A"),
    CATEGORY("CATEGORY", "GROUP", "Grouped by Category"),
    RECENTLY_WATCHED("RECENT", "RECENT", "Recently Watched First");

    fun nextOrder(): LiveChannelSortOrder {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }

    companion object {
        fun fromId(id: String?): LiveChannelSortOrder {
            return values().firstOrNull { it.id == id } ?: CHANNEL_NUMBER
        }
    }
}

enum class UiDensityMode(
    val id: String,
    val title: String,
    val subtitle: String,
    val tvPosterColumns: Int,
    val textScaleMultiplier: Float
) {
    COMPACT(
        id = "COMPACT",
        title = "Compact Density (6 Posters / Dense Rows)",
        subtitle = "Fits more posters and channels per screen on large 1080p/4K TVs",
        tvPosterColumns = 6,
        textScaleMultiplier = 0.94f
    ),
    STANDARD(
        id = "STANDARD",
        title = "Standard Density (5 Posters / Balanced)",
        subtitle = "Recommended default Android TV layout matching reference design",
        tvPosterColumns = 5,
        textScaleMultiplier = 1.0f
    ),
    CINEMATIC(
        id = "CINEMATIC",
        title = "Cinematic Comfortable (4 Large Posters / Larger Text)",
        subtitle = "Larger artwork cards and enhanced distance readability for living rooms",
        tvPosterColumns = 4,
        textScaleMultiplier = 1.10f
    );

    companion object {
        fun fromId(id: String?): UiDensityMode {
            return values().firstOrNull { it.id == id } ?: STANDARD
        }
    }
}

enum class PerformanceMode(
    val id: String,
    val title: String,
    val subtitle: String,
    val focusDebounceMs: Long,
    val adjacentDelayMs: Long,
    val maxPreloadSegmentBytes: Int,
    val allowAdjacentSegmentPreload: Boolean,
    val reducedAnimations: Boolean,
    val recommendedBufferProfileId: String
) {
    AUTO_ADAPTIVE(
        id = "AUTO_ADAPTIVE",
        title = "Auto Adaptive Mode (Fast Zap + Smart Hardware Sense)",
        subtitle = "Default: 30ms fast zapping + adaptive prefetch & animations tuned to device RAM and network",
        focusDebounceMs = 30L,
        adjacentDelayMs = 85L,
        maxPreloadSegmentBytes = 96 * 1024,
        allowAdjacentSegmentPreload = true,
        reducedAnimations = false,
        recommendedBufferProfileId = "ULTRA_ZAP"
    ),
    SMART_BALANCED(
        id = "SMART_BALANCED",
        title = "Smart Balanced Mode",
        subtitle = "Adaptive prefetching + smooth 4D transitions for everyday TV viewing",
        focusDebounceMs = 45L,
        adjacentDelayMs = 120L,
        maxPreloadSegmentBytes = 96 * 1024,
        allowAdjacentSegmentPreload = true,
        reducedAnimations = false,
        recommendedBufferProfileId = "LOW_MEM"
    ),
    FAST_ZAPPING(
        id = "FAST_ZAPPING",
        title = "Ultra Fast Zapping Mode",
        subtitle = "Hyper-responsive 24ms focus warm-up & instant HLS edge handoff on broadband Wi-Fi",
        focusDebounceMs = 24L,
        adjacentDelayMs = 65L,
        maxPreloadSegmentBytes = 112 * 1024,
        allowAdjacentSegmentPreload = true,
        reducedAnimations = false,
        recommendedBufferProfileId = "ULTRA_ZAP"
    ),
    LOW_MEMORY(
        id = "LOW_MEMORY",
        title = "Smart Low-Memory Mode (512MB Safe)",
        subtitle = "Conservative poster loading, reduced animations & strict RAM bounds for older TVs",
        focusDebounceMs = 85L,
        adjacentDelayMs = 240L,
        maxPreloadSegmentBytes = 48 * 1024,
        allowAdjacentSegmentPreload = false,
        reducedAnimations = true,
        recommendedBufferProfileId = "LOW_MEM"
    ),
    NETWORK_SAVER(
        id = "NETWORK_SAVER",
        title = "Network & Data Saver Mode",
        subtitle = "Manifest-only prefetch & bandwidth conservation for mobile hotspots / slow Wi-Fi",
        focusDebounceMs = 95L,
        adjacentDelayMs = 280L,
        maxPreloadSegmentBytes = 0,
        allowAdjacentSegmentPreload = false,
        reducedAnimations = false,
        recommendedBufferProfileId = "STABLE"
    );

    companion object {
        fun fromId(id: String?, isLowRamDevice: Boolean): PerformanceMode {
            return values().firstOrNull { it.id == id }
                ?: if (isLowRamDevice) AUTO_ADAPTIVE else FAST_ZAPPING
        }
    }
}

/**
 * Ultra-lean Channel / Catalog model for <=512 MB RAM Android Smart TVs (v18.1 Correct VOD Edition).
 *
 * Preserves full 8-parameter call-site compatibility while adding explicit [sourceType] and optional
 * genuine provider VOD/Series metadata fields.
 *
 * CRITICAL ARCHITECTURAL RULE:
 * - [isVodMovie], [isSeriesCatalogEntry], [isSeriesEpisode], and [primarySection] check ONLY [sourceType].
 * - They NEVER inspect channel name, group-title, category string, or file extension!
 */
data class Channel(
    val id: String,
    val number: Int,
    val name: String,
    val category: String,
    val streamUrl: String,
    val logoUrl: String = "",
    val epgId: String = "",
    val backupUrl: String = "",
    val sourceType: ContentSourceType = ContentSourceType.M3U_LIVE,
    val categoryId: String = "",
    val containerExtension: String = "",
    val releaseDate: String = "",
    val rating: String = "",
    val plot: String = "",
    val cast: String = "",
    val director: String = "",
    val durationLabel: String = "",
    val trailerUrl: String = "",
    val addedTimestamp: Long = 0L,
    val seriesId: String = ""
) {
    fun displayNumberFormatted(): String = when {
        number < 10 -> "00$number"
        number < 100 -> "0$number"
        else -> number.toString()
    }

    /**
     * Strictly checks explicit [sourceType] — NEVER guesses from channel title, category, or URL!
     */
    fun isLiveTvChannel(): Boolean = sourceType.isLiveTv()

    /**
     * Strictly checks explicit [sourceType] == [ContentSourceType.XTREAM_VOD_MOVIE].
     * Live TV channels (even if named "Bollywood Movies 24x7" or ending in `.mp4`) return FALSE.
     */
    fun isVodMovie(): Boolean = sourceType == ContentSourceType.XTREAM_VOD_MOVIE

    /**
     * Strictly checks explicit [sourceType] for Series or Series Episodes.
     * Live TV 24x7 series channels return FALSE.
     */
    fun isSeriesEpisode(): Boolean =
        sourceType == ContentSourceType.XTREAM_SERIES || sourceType == ContentSourceType.XTREAM_SERIES_EPISODE

    fun isSeriesCatalogEntry(): Boolean = sourceType == ContentSourceType.XTREAM_SERIES

    fun primarySection(): EntertainmentSection = when (sourceType) {
        ContentSourceType.XTREAM_VOD_MOVIE -> EntertainmentSection.MOVIES
        ContentSourceType.XTREAM_SERIES, ContentSourceType.XTREAM_SERIES_EPISODE -> EntertainmentSection.SERIES
        ContentSourceType.M3U_LIVE, ContentSourceType.XTREAM_LIVE -> EntertainmentSection.LIVE_TV
    }

    fun extractReleaseYear(): String {
        if (releaseDate.length >= 4 && releaseDate.substring(0, 4).all { it.isDigit() }) {
            return releaseDate.substring(0, 4)
        }
        return MediaCatalogEngine.extractYearFromTitle(name)
    }

    fun extractQualityBadge(): String {
        val badge = MediaCatalogEngine.extractQualityBadge(name, category, containerExtension.ifBlank { streamUrl })
        return badge
    }

    fun cleanMovieDisplayTitle(): String = MediaCatalogEngine.cleanDisplayTitle(name)

    companion object {
        const val DEFAULT_PROGRAM = "Live Broadcast"
        const val DEFAULT_NEXT_PROGRAM = "Upcoming Show"
    }
}

data class XtreamCredentials(
    val profileName: String,
    val serverUrl: String,
    val username: String,
    val password: String
)

data class EpgProgrammeDetail(
    val nowTitle: String,
    val nextTitle: String,
    val description: String = "",
    val timeWindow: String = "",
    val progressPercent: Int = 100
)

/**
 * Detailed Movie Metadata retrieved from Xtream `get_vod_info` + `get_vod_streams`.
 * Never fabricates ratings, cast, plot, director, or trailer URLs.
 */
data class VodMovieDetailInfo(
    val streamId: String,
    val title: String,
    val posterUrl: String,
    val backdropUrl: String = "",
    val releaseDate: String = "",
    val rating: String = "",
    val genre: String = "",
    val plot: String = "",
    val cast: String = "",
    val director: String = "",
    val durationLabel: String = "",
    val containerExtension: String = "mp4",
    val trailerUrl: String = ""
) {
    fun hasGenuineTrailer(): Boolean {
        val trimmed = trailerUrl.trim()
        if (trimmed.isEmpty()) return false
        return trimmed.length >= 5
    }
}

data class PlaybackProgressEntry(
    val contentId: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAtMs: Long,
    val contentType: ContentSourceType = ContentSourceType.XTREAM_VOD_MOVIE,
    val seriesKey: String = "",
    val seasonNumber: Int = 0,
    val episodeNumber: Int = 0
) {
    fun progressPercent(): Int {
        if (durationMs <= 0L) return 0
        return ((positionMs * 100L) / durationMs).toInt().coerceIn(1, 100)
    }

    fun isCompleted(): Boolean {
        if (durationMs <= 0L) return false
        return progressPercent() >= 95
    }

    fun isResumable(): Boolean {
        if (!contentType.isVodMovie() && !contentType.isSeriesEpisodeEntry() && !contentType.isSeriesCatalogEntry()) {
            return false
        }
        if (positionMs < 10_000L) return false
        if (durationMs <= 0L) return true
        return progressPercent() in 2..94
    }
}

data class SeriesEpisodeItem(
    val globalChannelIndex: Int,
    val channel: Channel,
    val seriesId: String,
    val seriesTitle: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val episodeTitle: String,
    val durationLabel: String = "",
    val plot: String = "",
    val releaseDate: String = ""
)

data class SeriesGroupSummary(
    val seriesKey: String,
    val seriesId: String,
    val title: String,
    val category: String,
    val categoryId: String = "",
    val posterUrl: String,
    val releaseDate: String = "",
    val releaseYear: String,
    val rating: String = "",
    val genre: String = "",
    val plot: String = "",
    val cast: String = "",
    val director: String = "",
    val qualityBadge: String,
    val addedTimestamp: Long = 0L,
    val representativeChannelIndex: Int,
    val seasons: Map<Int, List<SeriesEpisodeItem>>
) {
    val seasonCount: Int get() = seasons.size
    val totalEpisodes: Int get() = seasons.values.sumOf { it.size }
}

data class VodCategorySidebarItem(
    val categoryName: String,
    val count: Int,
    val isSpecialSection: Boolean = false
)

data class ZapBenchmarkMetrics(
    val keyPressToSelectionMs: Long,
    val selectionToPrepareMs: Long,
    val selectionToFirstFrameMs: Long,
    val channelSwitchCompletionMs: Long,
    val lastBufferingDurationMs: Long,
    val prefetchHitRatePercent: Int,
    val failedPrefetchRatePercent: Int
)

/**
 * Source-Aware Provider Metadata Helper (v18.1 Correct VOD Edition).
 *
 * CRITICAL GUARANTEE:
 * - Never converts a Live TV channel into a Movie or Series.
 * - Preserves actual Xtream provider category names verbatim (e.g., "BOLLYWOOD (2025-2026)",
 *   "SOUTH INDIAN", "PAK: HUM TV", "IND: SONY TV") without inventing fake categories.
 */
object MediaCatalogEngine {

    fun hasExplicitSeasonEpisodeToken(title: String): Boolean {
        val len = title.length
        if (len < 4) return false
        var i = 0
        while (i < len - 3) {
            val c = title[i]
            if ((c == 'S' || c == 's') && (i == 0 || !title[i - 1].isLetterOrDigit())) {
                var j = i + 1
                var sDigits = 0
                while (j < len && title[j].isDigit() && sDigits < 3) {
                    j++
                    sDigits++
                }
                if (sDigits in 1..2 && j < len) {
                    if (title[j] == ' ' || title[j] == '-' || title[j] == '.' || title[j] == '_') j++
                    if (j < len && (title[j] == 'E' || title[j] == 'e')) {
                        var k = j + 1
                        if (k < len && (title[k] == 'P' || title[k] == 'p')) k++
                        var eDigits = 0
                        while (k < len && title[k].isDigit() && eDigits < 4) {
                            k++
                            eDigits++
                        }
                        if (eDigits >= 1) return true
                    }
                }
            }
            i++
        }
        return false
    }

    fun extractYearFromTitle(title: String): String {
        val len = title.length
        if (len < 4) return ""
        var i = len - 4
        while (i >= 0) {
            val c0 = title[i]
            val c1 = title[i + 1]
            val c2 = title[i + 2]
            val c3 = title[i + 3]
            if (((c0 == '1' && c1 == '9') || (c0 == '2' && c1 == '0')) && c2.isDigit() && c3.isDigit()) {
                val year = (c0 - '0') * 1000 + (c1 - '0') * 100 + (c2 - '0') * 10 + (c3 - '0')
                val prevOk = i == 0 || !title[i - 1].isDigit()
                val nextOk = (i + 4 >= len) || !title[i + 4].isDigit()
                if (prevOk && nextOk && year in 1950..2035) {
                    return year.toString()
                }
            }
            i--
        }
        return ""
    }

    fun extractQualityBadge(title: String, category: String, extOrUrl: String): String {
        val combined = "$title $category".uppercase(Locale.ROOT)
        return when {
            combined.contains("4K") || combined.contains("UHD") || combined.contains("2160P") -> "4K UHD"
            combined.contains("1080P") || combined.contains("FHD") || combined.contains("FULL HD") -> "1080p"
            combined.contains("HEVC") || combined.contains("H265") || combined.contains("X265") -> "HEVC"
            combined.contains("720P") || combined.contains(" HD") || combined.endsWith("HD") -> "HD"
            combined.contains("WEB-DL") || combined.contains("WEBRIP") -> "WEB-DL"
            extOrUrl.equals("mkv", ignoreCase = true) || extOrUrl.endsWith(".mkv", ignoreCase = true) -> "MKV"
            extOrUrl.equals("mp4", ignoreCase = true) || extOrUrl.endsWith(".mp4", ignoreCase = true) -> "MP4"
            else -> ""
        }
    }

    fun cleanDisplayTitle(rawName: String): String {
        var cleaned = rawName.trim()
        if (cleaned.startsWith("🎬")) cleaned = cleaned.removePrefix("🎬").trim()
        if (cleaned.startsWith("📺")) cleaned = cleaned.removePrefix("📺").trim()
        return cleaned.ifBlank { rawName }
    }

    fun normalizeProviderCategory(rawCategory: String, section: EntertainmentSection, @Suppress("UNUSED_PARAMETER") itemName: String = ""): String {
        val stripped = rawCategory
            .removePrefix("🎬")
            .removePrefix("📺")
            .trim()
        if (stripped.isNotBlank()) {
            return stripped
        }
        return when (section) {
            EntertainmentSection.MOVIES -> "Uncategorized Movies"
            EntertainmentSection.SERIES -> "Uncategorized Series"
            EntertainmentSection.LIVE_TV -> "Live TV"
        }
    }

    /**
     * Converts Xtream `get_series` catalog items into [SeriesGroupSummary] entries.
     * Strictly accepts ONLY [ContentSourceType.XTREAM_SERIES] items — Live TV channels and Movies are ignored.
     */
    fun buildXtreamSeriesGroups(seriesCatalog: List<Channel>): List<SeriesGroupSummary> {
        if (seriesCatalog.isEmpty()) return emptyList()
        val summaries = ArrayList<SeriesGroupSummary>(seriesCatalog.size)
        for (idx in seriesCatalog.indices) {
            val ch = seriesCatalog[idx]
            if (ch.sourceType != ContentSourceType.XTREAM_SERIES) continue
            val cleanTitle = cleanDisplayTitle(ch.name)
            val normCategory = normalizeProviderCategory(ch.category, EntertainmentSection.SERIES, cleanTitle)
            val resolvedSeriesId = ch.seriesId.ifBlank { ch.id.removePrefix("series_") }
            val resolvedKey = "xtream_series_$resolvedSeriesId"
            summaries.add(
                SeriesGroupSummary(
                    seriesKey = resolvedKey,
                    seriesId = resolvedSeriesId,
                    title = cleanTitle,
                    category = normCategory,
                    categoryId = ch.categoryId,
                    posterUrl = ch.logoUrl,
                    releaseDate = ch.releaseDate,
                    releaseYear = ch.extractReleaseYear(),
                    rating = ch.rating,
                    genre = normCategory,
                    plot = ch.plot.ifBlank { ch.epgId },
                    cast = ch.cast,
                    director = ch.director,
                    qualityBadge = ch.extractQualityBadge(),
                    addedTimestamp = ch.addedTimestamp,
                    representativeChannelIndex = idx,
                    seasons = emptyMap()
                )
            )
        }
        return summaries
    }

    /**
     * Finds the genuine next episode within the SAME Series (either next episode in the same season
     * or Episode 1 of the next available season). Never selects an episode from another Series
     * and never restarts the same episode.
     */
    fun findNextEpisodeInSeries(
        group: SeriesGroupSummary,
        currentSeason: Int,
        currentEpisodeNumber: Int,
        currentEpisodeId: String
    ): SeriesEpisodeItem? {
        val sortedSeasons = group.seasons.keys.sorted()
        val seasonEps = group.seasons[currentSeason].orEmpty().sortedBy { it.episodeNumber }
        val currentIdx = seasonEps.indexOfFirst {
            it.channel.id == currentEpisodeId || it.episodeNumber == currentEpisodeNumber
        }
        if (currentIdx >= 0 && currentIdx + 1 < seasonEps.size) {
            val candidate = seasonEps[currentIdx + 1]
            if (candidate.channel.id != currentEpisodeId) {
                return candidate
            }
        }
        val seasonPos = sortedSeasons.indexOf(currentSeason)
        if (seasonPos >= 0 && seasonPos + 1 < sortedSeasons.size) {
            val nextSeasonNum = sortedSeasons[seasonPos + 1]
            val nextSeasonEps = group.seasons[nextSeasonNum].orEmpty().sortedBy { it.episodeNumber }
            val firstOfNextSeason = nextSeasonEps.firstOrNull()
            if (firstOfNextSeason != null && firstOfNextSeason.channel.id != currentEpisodeId) {
                return firstOfNextSeason
            }
        }
        return null
    }

    /**
     * Finds the genuine previous episode within the SAME Series.
     */
    fun findPreviousEpisodeInSeries(
        group: SeriesGroupSummary,
        currentSeason: Int,
        currentEpisodeNumber: Int,
        currentEpisodeId: String
    ): SeriesEpisodeItem? {
        val sortedSeasons = group.seasons.keys.sorted()
        val seasonEps = group.seasons[currentSeason].orEmpty().sortedBy { it.episodeNumber }
        val currentIdx = seasonEps.indexOfFirst {
            it.channel.id == currentEpisodeId || it.episodeNumber == currentEpisodeNumber
        }
        if (currentIdx > 0) {
            return seasonEps[currentIdx - 1]
        }
        val seasonPos = sortedSeasons.indexOf(currentSeason)
        if (seasonPos > 0) {
            val prevSeasonNum = sortedSeasons[seasonPos - 1]
            val prevSeasonEps = group.seasons[prevSeasonNum].orEmpty().sortedBy { it.episodeNumber }
            return prevSeasonEps.lastOrNull()
        }
        return null
    }
}
